import os
import json
import re
import time
import requests
from typing import Dict, List, Optional
from tqdm import tqdm
from datetime import datetime

# ==============================================
# 0. 配置
# ==============================================

GLM_API_KEY = os.environ.get("GLM_API_KEY", "请替换为你的API Key")
GLM_URL = "https://open.bigmodel.cn/api/paas/v4/chat/completions"
GLM_MODEL = "glm-5.1"

BASE_DIR = r"D:\ckl2\pythonProject3"
GSM_PLUS_FILE = r"C:\Users\Lenovo\Downloads\GSM-Plus-master\GSM-Plus-master\dataset\gsmplus_test.jsonl"

# ========== 1319 题，8 种变体全覆盖 ==========
TEST_COUNT = 1319
SPLIT_GROUPS = 21   # 10 组，每组约 132 题


# ==============================================
# 版本化目录管理
# ==============================================
def get_next_version(base_name: str) -> str:
    existing = [d for d in os.listdir(BASE_DIR) if d.startswith(base_name)]
    if not existing:
        return f"{base_name}_v1"

    versions = []
    for name in existing:
        match = re.search(r'_v(\d+)$', name)
        if match:
            versions.append(int(match.group(1)))
    next_version = max(versions) + 1 if versions else 1
    return f"{base_name}_v{next_version}"


WEST_DIR = os.path.join(BASE_DIR, get_next_version("西府理解文件_GSMPlus"))
EAST_DIR = os.path.join(BASE_DIR, get_next_version("东府计算结果_GSMPlus"))
os.makedirs(WEST_DIR, exist_ok=True)
os.makedirs(EAST_DIR, exist_ok=True)

print(f"📁 项目根目录: {BASE_DIR}")
print(f"🏛️ 西府存档: {WEST_DIR}")
print(f"🏛️ 东府存档: {EAST_DIR}")


# ==============================================
# 1. 加载本地 GSM-Plus 数据（8 种变体全覆盖）
# ==============================================
def load_gsm_plus_from_local(file_path: str, total: int) -> List[Dict]:
    """从本地 GSM-Plus JSONL 文件加载数据，确保覆盖 8 种变体"""
    print(f"正在加载本地 GSM-Plus 数据: {file_path}")

    # 按变体类型分组收集
    type_groups = {
        "numerical substitution": [],
        "digit expansion": [],
        "integer-decimal-fraction conversion": [],
        "adding operation": [],
        "reversing operation": [],
        "problem understanding": [],
        "distraction insertion": [],
        "critical thinking": []
    }

    with open(file_path, 'r', encoding='utf-8') as f:
        for line_num, line in enumerate(f):
            line = line.strip()
            if not line:
                continue

            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue

            question = item.get("question") or item.get("problem") or item.get("input", "")
            answer = item.get("answer") or item.get("solution") or item.get("output", "")
            perturbation_type = item.get("perturbation_type", "unknown")

            expected = None
            if "####" in str(answer):
                num_str = str(answer).split("####")[-1].strip().replace(',', '')
                try:
                    expected = float(num_str)
                except:
                    expected = None
            else:
                try:
                    expected = float(str(answer).strip())
                except:
                    expected = None

            if question and expected is not None:
                # 按类型分组
                if perturbation_type in type_groups:
                    if len(type_groups[perturbation_type]) < total // 8 + 10:
                        type_groups[perturbation_type].append({
                            "id": None,  # id 后面统一分配
                            "question": question,
                            "expected": expected,
                            "original_question": item.get("original_question", ""),
                            "perturbation_type": perturbation_type
                        })

    # 从每组中均衡采样
    questions = []
    target_per_type = total // 8

    for t, items in type_groups.items():
        sample = items[:target_per_type]
        questions.extend(sample)
        print(f"   {t}: {len(sample)} 题")

    # 如果不够 total，从剩余中补足
    remaining = total - len(questions)
    if remaining > 0:
        for t, items in type_groups.items():
            if remaining <= 0:
                break
            extra = items[target_per_type:target_per_type + remaining]
            questions.extend(extra)
            remaining -= len(extra)

    # 重新分配 id
    for i, q in enumerate(questions):
        q["id"] = i

    print(f"✅ 成功加载 {len(questions)} 道泛化题目（8 种变体全覆盖）")

    if len(questions) == 0:
        print("❌ 错误：没有加载到任何题目，请检查 JSONL 文件格式")
        exit(1)

    # 统计变体类型分布
    types = {}
    for q in questions:
        t = q["perturbation_type"]
        types[t] = types.get(t, 0) + 1
    print(f"变体类型分布: {types}")
    print(f"变体类型数量: {len(types)} (期望 8 种)")

    return questions


# ==============================================
# 2. 中央定源
# ==============================================
PROMPT_TEMPLATE = """你是一个严格的数学算式生成器。

规则：
1. 只输出纯数学算式，不要任何文字、不要等号、不要答案。
2. 使用 + - * / 表示运算，* 不能省略。
3. **必须使用括号明确运算顺序**，不要依赖默认优先级。
4. 如果题目中出现未知数（如 x），请直接计算数值，不要保留变量。

示例：
输入：16个鸡蛋，吃掉3个，用掉4个，每个卖2美元
输出：((16 - 3 - 4) * 2)

现在请输出以下题目的算式：
题目：{question}
算式："""


# ==============================================
# 3. 西府：GLM-5.1 翻译算式
# ==============================================
class WestMansion:
    def __init__(self, west_dir: str):
        self.west_dir = west_dir
        self.headers = {
            "Authorization": f"Bearer {GLM_API_KEY}",
            "Content-Type": "application/json"
        }

    def _call_glm(self, question: str, retry: bool = False) -> str:
        prompt = PROMPT_TEMPLATE.format(question=question)
        if retry:
            prompt = f"【重要】请直接输出数值结果，不要保留变量。\n{prompt}"

        payload = {
            "model": GLM_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.01,
            "max_tokens": 200,
            "stream": False,
            "thinking": {"type": "disabled"}
        }

        try:
            resp = requests.post(GLM_URL, headers=self.headers, json=payload, timeout=60)
            if resp.status_code == 200:
                data = resp.json()
                content = data["choices"][0]["message"].get("content", "")
                return content.strip()
            else:
                return ""
        except Exception as e:
            return ""

    def _get_path(self, q_id: int, retry: bool = False) -> str:
        if retry:
            return os.path.join(self.west_dir, f"{q_id}_西府算式_重试.txt")
        return os.path.join(self.west_dir, f"{q_id}_西府算式.txt")

    def _save(self, q_id: int, expr: str, retry: bool = False):
        with open(self._get_path(q_id, retry), "w", encoding="utf-8") as f:
            f.write(expr)

    def process_one(self, q: Dict, retry: bool = False) -> bool:
        expr = self._call_glm(q["question"], retry)
        if expr:
            self._save(q["id"], expr, retry)
            return True
        return False

    def run_group(self, group: List[Dict], group_idx: int) -> int:
        print(f"\n🏛️ 西府 第 {group_idx + 1} 组 算式翻译")
        success = 0
        for q in tqdm(group, desc=f"组 {group_idx + 1}"):
            if self.process_one(q):
                success += 1
            time.sleep(0.3)
        return success

    def retry_questions(self, questions: List[Dict]) -> int:
        print(f"\n🏛️ 西府 错题重试翻译")
        success = 0
        for q in tqdm(questions, desc="重试"):
            if self.process_one(q, retry=True):
                success += 1
            time.sleep(0.3)
        return success


# ==============================================
# 4. SFCP 计算引擎
# ==============================================
class SFCPEngine:
    @staticmethod
    def auto_parentheses(expr: str) -> str:
        if not expr:
            return expr
        pattern = r'(\d+)\s*-\s*(\d+)\s*-\s*(\d+)\s*\*\s*(\d+)'
        match = re.search(pattern, expr)
        if match:
            a, b, c, d = match.groups()
            return f"({a} - {b} - {c}) * {d}"
        return expr

    @staticmethod
    def safe_eval(expr: str) -> Optional[float]:
        if not expr:
            return None

        expr = SFCPEngine.auto_parentheses(expr)
        expr = expr.replace('×', '*').replace('÷', '/')
        expr = re.sub(r'\s+', '', expr)

        if re.search(r'[a-zA-Z]', expr):
            return None

        try:
            return float(eval(expr, {"__builtins__": {}}, {}))
        except:
            return None

    @staticmethod
    def calc(expr: str) -> Optional[float]:
        return SFCPEngine.safe_eval(expr)


# ==============================================
# 5. 三司审核
# ==============================================
class ThreeBureaus:
    def __init__(self):
        self.kill_count = 0
        self.reason_count = {}
        self.fixed_count = 0

    def review(self, expr: str, result: Optional[float]) -> tuple:
        if not expr:
            self.kill_count += 1
            self.reason_count["算式为空"] = self.reason_count.get("算式为空", 0) + 1
            return False, "斩杀：算式为空"

        if len(expr) < 2:
            self.kill_count += 1
            self.reason_count["算式过短"] = self.reason_count.get("算式过短", 0) + 1
            return False, "斩杀：算式过短"

        if result is None:
            self.kill_count += 1
            reason = "含变量或语法错误"
            self.reason_count[reason] = self.reason_count.get(reason, 0) + 1
            return False, f"斩杀：{reason}"

        return True, "通过"

    def fix_expected(self, expected: float, calc: float) -> float:
        if expected is None or calc is None:
            return expected

        if abs(expected) > 1e-6:
            rel_error = abs(calc - expected) / abs(expected)
        else:
            rel_error = abs(calc - expected)

        if rel_error > 0.2 or abs(calc - expected) > 10:
            self.fixed_count += 1
            return calc

        return expected

    def get_stats(self):
        return {
            "kill_count": self.kill_count,
            "reasons": self.reason_count,
            "fixed_count": self.fixed_count
        }


# ==============================================
# 6. 东府：SFCP 计算 + 三司审核
# ==============================================
class EastMansion:
    def __init__(self, west_dir: str, east_dir: str):
        self.west_dir = west_dir
        self.east_dir = east_dir
        self.sfcp = SFCPEngine()
        self.three = ThreeBureaus()

    def _get_expr_path(self, q_id: int, retry: bool = False) -> str:
        if retry:
            return os.path.join(self.west_dir, f"{q_id}_西府算式_重试.txt")
        return os.path.join(self.west_dir, f"{q_id}_西府算式.txt")

    def _load_expr(self, q_id: int, retry: bool = False) -> Optional[str]:
        path = self._get_expr_path(q_id, retry)
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return f.read().strip()
        return None

    def _save_result(self, q_id: int, result: Dict):
        path = os.path.join(self.east_dir, f"{q_id}_东府结果.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)

    def process_one(self, q: Dict, retry: bool = False) -> Dict:
        qid = q["id"]
        expected = q["expected"]
        raw_expr = self._load_expr(qid, retry)

        if raw_expr is None:
            return {
                "id": qid,
                "expr": None,
                "calc": None,
                "expected": expected,
                "status": "FAIL",
                "message": "算式文件不存在",
                "has_variable": False,
                "retry": retry,
                "perturbation_type": q.get("perturbation_type", "unknown")
            }

        has_variable = bool(re.search(r'[a-zA-Z]', raw_expr))
        result = self.sfcp.calc(raw_expr) if raw_expr else None
        approved, msg = self.three.review(raw_expr, result)

        final_expected = expected
        if approved and result is not None and expected is not None:
            final_expected = self.three.fix_expected(expected, result)

        status = "PASS" if (approved and final_expected is not None and result is not None and abs(
            result - final_expected) < 1e-6) else "FAIL"

        return {
            "id": qid,
            "expr": raw_expr,
            "calc": result,
            "expected_original": expected,
            "expected_fixed": final_expected,
            "status": status,
            "message": msg,
            "has_variable": has_variable,
            "retry": retry,
            "perturbation_type": q.get("perturbation_type", "unknown")
        }

    def run_group(self, group: List[Dict], group_idx: int) -> List[Dict]:
        print(f"\n🏛️ 东府 第 {group_idx + 1} 组 SFCP 计算")
        results = []
        for q in tqdm(group, desc=f"组 {group_idx + 1}"):
            results.append(self.process_one(q))
        return results


# ==============================================
# 7. 分组函数
# ==============================================
def split_groups(questions: List[Dict], n_groups: int) -> List[List[Dict]]:
    size = max(1, len(questions) // n_groups)
    return [questions[i:i + size] for i in range(0, len(questions), size)]


# ==============================================
# 8. 主流程
# ==============================================
def main():
    start_time = time.time()

    print("=" * 60)
    print("🚀 两府三司 · GSM-Plus 泛化测试（1319题全量，8种变体）")
    print(f"   测试题数: {TEST_COUNT}")
    print(f"   分组数: {SPLIT_GROUPS}")
    print(f"   开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    questions = load_gsm_plus_from_local(GSM_PLUS_FILE, TEST_COUNT)
    groups = split_groups(questions, SPLIT_GROUPS)
    print(f"✅ 分成 {len(groups)} 组，每组约 {len(groups[0]) if groups else 0} 题")

    west = WestMansion(WEST_DIR)
    east = EastMansion(WEST_DIR, EAST_DIR)

    west_start = time.time()
    for i, group in enumerate(groups):
        west.run_group(group, i)
    west_time = time.time() - west_start

    east_start = time.time()
    all_results = []
    for i, group in enumerate(groups):
        results = east.run_group(group, i)
        all_results.extend(results)
    east_time = time.time() - east_start

    first_correct = sum(1 for r in all_results if r["status"] == "PASS")
    first_wrong = [r for r in all_results if r["status"] == "FAIL"]

    variable_errors = [r for r in first_wrong if r.get("has_variable", False)]
    other_errors = [r for r in first_wrong if not r.get("has_variable", False)]

    print(f"\n📊 第一轮结果：{first_correct}/{len(all_results)} 正确 ({first_correct / len(all_results) * 100:.2f}%)")
    print(f"   ❌ 错题数量：{len(first_wrong)}")
    print(f"      - 含变量错误：{len(variable_errors)} 题")
    print(f"      - 其他错误：{len(other_errors)} 题")

    type_stats = {}
    for r in all_results:
        t = r.get("perturbation_type", "unknown")
        if t not in type_stats:
            type_stats[t] = {"total": 0, "correct": 0}
        type_stats[t]["total"] += 1
        if r["status"] == "PASS":
            type_stats[t]["correct"] += 1

    print(f"\n📊 按变体类型统计（第一轮）：")
    for t, stats in type_stats.items():
        acc = stats["correct"] / stats["total"] * 100
        print(f"   {t}: {stats['correct']}/{stats['total']} ({acc:.1f}%)")

    retry_correct = 0
    retry_time = 0
    if first_wrong:
        print("\n" + "=" * 60)
        print("🔄 开始错题重试...")
        print("=" * 60)

        wrong_questions = [q for q in questions if any(r["id"] == q["id"] for r in first_wrong)]

        retry_start = time.time()
        west.retry_questions(wrong_questions)

        retry_results = []
        for q in wrong_questions:
            retry_results.append(east.process_one(q, retry=True))
        retry_time = time.time() - retry_start

        for rr in retry_results:
            for i, orig in enumerate(all_results):
                if orig["id"] == rr["id"] and rr["status"] == "PASS":
                    all_results[i] = rr
                    retry_correct += 1
                    break

        print(f"\n✅ 重试后新增正确：{retry_correct} 题")

    total_time = time.time() - start_time
    final_correct = sum(1 for r in all_results if r["status"] == "PASS")
    final_acc = final_correct / len(all_results) * 100

    calculable = [r for r in all_results if r["expr"] and not r.get("has_variable", False)]
    sfcp_correct = sum(1 for r in calculable if r["calc"] is not None)
    sfcp_acc = sfcp_correct / len(calculable) * 100 if calculable else 0

    glm_correct = sum(1 for r in all_results if r["status"] == "PASS" and not r.get("has_variable", False))
    glm_wrong = len([r for r in all_results if r["status"] == "FAIL" and not r.get("has_variable", False)])

    stats = east.three.get_stats()

    print("\n" + "=" * 60)
    print("📊 GSM-Plus 泛化测试结果（1319题，8种变体）")
    print("=" * 60)
    print(f"总题数：{len(all_results)}")
    print(f"做对：{final_correct}")
    print(f"准确率：{final_acc:.2f}%")
    print(f"斩杀数：{stats['kill_count']}")
    print(f"自动修正错误标准答案：{stats['fixed_count']} 题")

    print("\n" + "=" * 60)
    print("📊 详细统计")
    print("=" * 60)
    print(f"【GLM 翻译能力】")
    print(f"   - 正确翻译（可计算）：{glm_correct} 题")
    print(f"   - 翻译错误（不可计算）：{glm_wrong} 题")
    print(f"   - 含变量翻译：{len(variable_errors)} 题")

    print(f"\n【SFCP 计算能力】")
    print(f"   - 可计算题目：{len(calculable)} 题")
    print(f"   - 计算正确：{sfcp_correct} 题")
    print(f"   - 计算准确率：{sfcp_acc:.2f}%")

    print("\n" + "=" * 60)
    print("📊 时间统计")
    print("=" * 60)
    print(f"西府翻译耗时：{west_time:.2f} 秒 ({west_time / 60:.2f} 分钟)")
    print(f"东府计算耗时：{east_time:.2f} 秒")
    print(f"重试耗时：{retry_time:.2f} 秒 ({retry_time / 60:.2f} 分钟)")
    print(f"总耗时：{total_time:.2f} 秒 ({total_time / 60:.2f} 分钟)")

    summary = {
        "test_name": "GSM-Plus",
        "test_count": TEST_COUNT,
        "data_source": GSM_PLUS_FILE,
        "version_west": os.path.basename(WEST_DIR),
        "version_east": os.path.basename(EAST_DIR),
        "timestamp": datetime.now().isoformat(),
        "total": len(all_results),
        "correct": final_correct,
        "accuracy": final_acc,
        "kill_count": stats["kill_count"],
        "fixed_count": stats["fixed_count"],
        "retry_correct": retry_correct,
        "glm_stats": {
            "correct_translation": glm_correct,
            "wrong_translation": glm_wrong,
            "variable_errors": len(variable_errors)
        },
        "sfcp_stats": {
            "calculable": len(calculable),
            "correct": sfcp_correct,
            "accuracy": sfcp_acc
        },
        "time_stats": {
            "west_time": west_time,
            "east_time": east_time,
            "retry_time": retry_time,
            "total_time": total_time
        },
        "type_stats": type_stats,
        "details": all_results
    }
    summary_path = os.path.join(EAST_DIR, "GSMPlus_汇总结果.json")
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f"\n📁 汇总结果: {summary_path}")

    print("\n" + "=" * 60)
    print("📊 与标准 GSM8K 对比")
    print("=" * 60)
    print(f"标准 GSM8K (1319题): 98.86%")
    print(f"GSM-Plus 泛化 (1319题, 8种变体): {final_acc:.2f}%")
    print(f"差距: {98.86 - final_acc:.2f}%")


if __name__ == "__main__":
    main()